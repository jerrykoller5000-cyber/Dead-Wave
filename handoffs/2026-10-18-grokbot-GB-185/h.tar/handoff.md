# Grokbot — GB-185 Rounds land — 2026-10-18
Changed:          Nothing in game code. Found the break: the real game hits fine; the suite's fake three.js (tools/tests/fakethree.mjs) has a Raycaster whose intersectObject(s) always return [], and since GP-19885 rounds and the cursor use a raycast against the posed body (zombieSurface), so in the suite no round can ever hit a zombie. The fix belongs in Cursor's fakethree; requested with a drop-in proposal.
Files:            none changed (proposal: handoffs/2026-10-18-grokbot-GB-185/fakethree-raycast-proposal.js; probes: probe.js, probe.ps1, probe2.txt, probe3.txt in that folder)
Tests:            t69 16/2, t211 21/5, t222 3/6 (as before, red in the suite only). Live game (camera --match, real three.js) probe: a shambler shot at once after spawn 22 -> dead, after a surface query 23 -> dead, after 1.2 s 21 -> dead; zombieSurface hits the chest (t 0.65), 15 body meshes, 13 skinSrc, none hidden.
                  Commands: node crew/crew.mjs slot run grokbot GB-185 ... probe.ps1 (camera start --match, eval probe.js, stop); node tools/tests/run-all.mjs t69 t211 t222 --no-retry --all-fails --jobs 1 (via slot run).
Screenshots:      none (no visible change)
Not verified:     That every listed red (t63, t80, t90, t91, t93 head, t107, t111, t119, t128, t155, t156, t164, t248) goes green once fakethree raycasts; t211's belt-change/HUD lines and t222's reticle lines may have their own causes. GP-19922/19924 (smoothing, joins) are cleared as suspects for the real game.
Requests:         Cursor: real Raycaster.intersectObject(s) + Mesh.raycast in tools/tests/fakethree.mjs (sent with crew.mjs request). ChatGPT (GP-19929): FYI, the joins/smoothing don't break the hit test in the real game.
Contract changes: none
Rule 16: every game run went through the automatic slot queue (crew slot run), one instance, --jobs 1.
