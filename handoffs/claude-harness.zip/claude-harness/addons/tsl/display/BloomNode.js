export const bloom = () => ({});
